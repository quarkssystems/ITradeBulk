require.config({
    
    shim: {        
        'jquery_steps':     ['jquery'],
        //'jquery_validate':  ['jquery'],
    },
    
    paths: {
        'jquery_steps':         '../assets/plugins/jquery-steps/jquery.steps',
        //'jquery_validate':      '../assets/plugins/jquery-validation/jquery.validate.js',
    }
});
