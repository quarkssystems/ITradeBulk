require.config({
    
    shim: {        
        'parsleyjs':                    ['bootstrap_multiselect','jquery'],        
    },
    
    paths: {
        'parsleyjs':                        '../assets/plugins/parsleyjs/js/parsley.min',
    }
});


